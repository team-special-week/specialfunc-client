const todolist = [
  {
    "userId": 1,
    "id": 1,
    "body": "Nothing"
  },
  {
    "userId": 1,
    "id": 2,
    "body": "Coding"
  },
  {
    "userId": 1,
    "id": 3,
    "body": "Sleep"
  },
  {
    "userId": 2,
    "id": 4,
    "body": "Game"
  },
  {
    "userId": 2,
    "id": 5,
    "body": "Take a shower"
  },
  {
    "userId": 2,
    "id": 6,
    "body": "Breathing"
  },
  {
    "userId": 3,
    "id": 7,
    "body": "Eat mint chocolate"
  },
  {
    "userId": 3,
    "id": 8,
    "body": "Listening music"
  },
  {
    "userId": 3,
    "id": 9,
    "body": "Go to school :C"
  },
]

exports.main = async function(req) {
  let id = 0;
  let userId = req.headers.Authorization;
  {
    const block = req.url.split('/');
    id = block[block.length - 1];
  }

  todolisttodolist.find({id: id}).remove();
  return todolist;
}

