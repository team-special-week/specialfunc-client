exports.main = async function(req) {
    return "Hello world"
}