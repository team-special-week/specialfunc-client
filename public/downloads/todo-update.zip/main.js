const todolist = [
  {
    "id": 1,
    "body": "Nothing"
  },
  {
    "id": 2,
    "body": "Coding"
  },
  {
    "id": 3,
    "body": "Sleep"
  },
  {
    "id": 4,
    "body": "Game"
  },
  {
    "id": 5,
    "body": "Take a shower"
  },
  {
    "id": 6,
    "body": "Breathing"
  },
  {
    "id": 7,
    "body": "Eat mint chocolate"
  },
  {
    "id": 8,
    "body": "Listening music"
  },
  {
    "id": 9,
    "body": "Go to school :C"
  },
]

exports.main = async function(req) {
  try {
    let id = 0;
    {
      const block = req.url.split('/');
      id = block[block.length - 1];
    }

    const updateList = req.body.content;
    todolist.find({'id': id}).update({'id' : id, 'body' : updateList});
    return todolist;
  } catch (error){
    return {};
  }
}

